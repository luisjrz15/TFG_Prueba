package com.tfg.api.entity;

public enum Servicio {
    Reparacion,
    Modificacion
}