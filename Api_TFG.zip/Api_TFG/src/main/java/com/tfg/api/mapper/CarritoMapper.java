package com.tfg.api.mapper;

import com.tfg.api.dto.CarritoDTO;
import com.tfg.api.entity.Carrito;

public class CarritoMapper {

    public static CarritoDTO toDTO(Carrito entity) {
        if (entity == null) return null;

        CarritoDTO dto = new CarritoDTO();
        dto.setIdCarrito(entity.getIdCarrito());
        dto.setCantidad(entity.getCantidad());

        if (entity.getUsuario() != null) {
            dto.setIdUsuario(entity.getUsuario().getIdUsuario());
        }

        dto.setProducto(ProductoMapper.toDTO(entity.getProducto()));

        return dto;
    }
}