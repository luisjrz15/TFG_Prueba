package com.tfg.api.service;

import com.tfg.api.dto.ResenaCreateDTO;
import com.tfg.api.dto.ResenaDTO;

import java.util.List;

public interface ResenaService {

    List<ResenaDTO> findAll();

    List<ResenaDTO> findByProducto(Integer idProducto);

    ResenaDTO findById(Integer id);

    ResenaDTO save(ResenaCreateDTO dto);

    void deleteById(Integer id);
}