package com.tfg.api.service.impl;

import com.tfg.api.dto.ResenaCreateDTO;
import com.tfg.api.dto.UsuarioCreateDTO;
import com.tfg.api.dto.UsuarioDTO;
import com.tfg.api.entity.Usuario;
import com.tfg.api.mapper.UsuarioMapper;
import com.tfg.api.repository.UsuarioRepository;
import com.tfg.api.service.UsuarioService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioServiceImpl(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public List<UsuarioDTO> findAll() {
        return usuarioRepository.findAll()
                .stream()
                .map(UsuarioMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public UsuarioDTO findById(Integer id) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        return UsuarioMapper.toDTO(usuario);
    }

    @Override
    public UsuarioDTO save(UsuarioCreateDTO dto) {

        Usuario usuario = new Usuario();
        usuario.setNombreUsuario(dto.getNombreUsuario());
        usuario.setEmail(dto.getEmail());

        //  AUN SIN SECURITY 
        usuario.setPassword(dto.getPassword());

        Usuario saved = usuarioRepository.save(usuario);
        return UsuarioMapper.toDTO(saved);
    }

    @Override
    public UsuarioDTO update(Integer id, UsuarioDTO dto) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        usuario.setNombreUsuario(dto.getNombreUsuario());
        usuario.setEmail(dto.getEmail());

        return UsuarioMapper.toDTO(usuarioRepository.save(usuario));
    }

    @Override
    public void deleteById(Integer id) {
        usuarioRepository.deleteById(id);
    }  
}
    
