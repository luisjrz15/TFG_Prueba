package com.tfg.api.service.impl;

import com.tfg.api.dto.FormularioDTO;
import com.tfg.api.entity.*;
import com.tfg.api.mapper.FormularioMapper;
import com.tfg.api.repository.FormularioRepository;
import com.tfg.api.repository.UsuarioRepository;
import com.tfg.api.service.FormularioService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FormularioServiceImpl implements FormularioService {

    private final FormularioRepository formularioRepository;
    private final UsuarioRepository usuarioRepository;

    public FormularioServiceImpl(FormularioRepository formularioRepository,
                                 UsuarioRepository usuarioRepository) {
        this.formularioRepository = formularioRepository;
        this.usuarioRepository = usuarioRepository;
    }

    // 🔹 GET ALL
    @Override
    public List<FormularioDTO> findAll() {
        return formularioRepository.findAll()
                .stream()
                .map(FormularioMapper::toDTO)
                .collect(Collectors.toList());
    }

    // 🔹 GET BY ID
    @Override
    public FormularioDTO findById(Integer id) {
        Formulario formulario = formularioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Formulario no encontrado"));

        return FormularioMapper.toDTO(formulario);
    }

    // 🔹 CREATE
    @Override
    public FormularioDTO save(FormularioDTO dto) {
        Formulario formulario = new Formulario();

        mapDtoToEntity(dto, formulario);

        Formulario saved = formularioRepository.save(formulario);
        return FormularioMapper.toDTO(saved);
    }

    // 🔹 UPDATE
    @Override
    public FormularioDTO update(Integer id, FormularioDTO dto) {
        Formulario formulario = formularioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Formulario no encontrado"));

        mapDtoToEntity(dto, formulario);

        Formulario updated = formularioRepository.save(formulario);
        return FormularioMapper.toDTO(updated);
    }

    // 🔹 DELETE
    @Override
    public void deleteById(Integer id) {
        if (!formularioRepository.existsById(id)) {
            throw new RuntimeException("Formulario no encontrado");
        }
        formularioRepository.deleteById(id);
    }

    // 🔹 Método privado de mapeo DTO → Entity
    private void mapDtoToEntity(FormularioDTO dto, Formulario formulario) {

        formulario.setDescripcion(dto.getDescripcion());
        formulario.setPresupuesto(dto.getPresupuesto());

        if (dto.getServicio() != null) {
            formulario.setServicio(Servicio.valueOf(dto.getServicio()));
        }

        if (dto.getEstado() != null) {
            formulario.setEstado(EstadoFormulario.valueOf(dto.getEstado()));
        }

        if (dto.getIdUsuario() != null) {
            Usuario usuario = usuarioRepository.findById(dto.getIdUsuario())
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
            formulario.setUsuario(usuario);
        }
    }
}