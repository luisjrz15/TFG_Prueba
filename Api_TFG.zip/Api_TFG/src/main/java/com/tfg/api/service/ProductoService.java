package com.tfg.api.service;

import com.tfg.api.dto.ProductoDTO;

import java.util.List;

public interface ProductoService {

    List<ProductoDTO> findAll();

    ProductoDTO findById(Integer id);

    ProductoDTO save(ProductoDTO dto);

    ProductoDTO update(Integer id, ProductoDTO dto);

    void deleteById(Integer id);
}