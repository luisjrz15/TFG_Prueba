package com.tfg.api.mapper;

import com.tfg.api.dto.ProductoDTO;
import com.tfg.api.entity.Producto;

public class ProductoMapper {

    public static ProductoDTO toDTO(Producto entity) {
        if (entity == null) return null;

        ProductoDTO dto = new ProductoDTO();
        dto.setIdProducto(entity.getIdProducto());
        dto.setIdCategoria(entity.getIdCategoria());
        dto.setNombre(entity.getNombre());
        dto.setDescripcion(entity.getDescripcion());
        dto.setPrecio(entity.getPrecio());
        dto.setStock(entity.getStock());
        dto.setImagenUrl(entity.getImagenUrl());

        return dto;
    }
}
