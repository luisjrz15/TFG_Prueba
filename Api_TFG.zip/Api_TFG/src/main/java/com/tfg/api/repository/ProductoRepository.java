package com.tfg.api.repository;

import com.tfg.api.entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    List<Producto> findByIdCategoria(Integer idCategoria);
}