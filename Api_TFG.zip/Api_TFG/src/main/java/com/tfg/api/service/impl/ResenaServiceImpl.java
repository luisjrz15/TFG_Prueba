package com.tfg.api.service.impl;

import com.tfg.api.dto.ResenaCreateDTO;
import com.tfg.api.dto.ResenaDTO;
import com.tfg.api.entity.Producto;
import com.tfg.api.entity.Resena;
import com.tfg.api.entity.Usuario;
import com.tfg.api.mapper.ResenaMapper;
import com.tfg.api.repository.ProductoRepository;
import com.tfg.api.repository.ResenaRepository;
import com.tfg.api.repository.UsuarioRepository;
import com.tfg.api.service.ResenaService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ResenaServiceImpl implements ResenaService {

    private final ResenaRepository resenaRepository;
    private final UsuarioRepository usuarioRepository;
    private final ProductoRepository productoRepository;

    public ResenaServiceImpl(ResenaRepository resenaRepository,
                             UsuarioRepository usuarioRepository,
                             ProductoRepository productoRepository) {
        this.resenaRepository = resenaRepository;
        this.usuarioRepository = usuarioRepository;
        this.productoRepository = productoRepository;
    }

    @Override
    public List<ResenaDTO> findAll() {
        return resenaRepository.findAll()
                .stream()
                .map(ResenaMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<ResenaDTO> findByProducto(Integer idProducto) {
        return resenaRepository.findByProductoIdProducto(idProducto)
                .stream()
                .map(ResenaMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ResenaDTO findById(Integer id) {
        Resena resena = resenaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reseña no encontrada"));

        return ResenaMapper.toDTO(resena);
    }

    @Override
    public ResenaDTO save(ResenaCreateDTO dto) {

        Usuario usuario = usuarioRepository.findById(dto.getIdUsuario())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Producto producto = productoRepository.findById(dto.getIdProducto())
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        Resena resena = new Resena();
        resena.setUsuario(usuario);
        resena.setProducto(producto);
        resena.setPuntuacion(dto.getPuntuacion());
        resena.setComentario(dto.getComentario());

        return ResenaMapper.toDTO(resenaRepository.save(resena));
    }

    @Override
    public void deleteById(Integer id) {
        if (!resenaRepository.existsById(id)) {
            throw new RuntimeException("Reseña no encontrada");
        }
        resenaRepository.deleteById(id);
    }
}