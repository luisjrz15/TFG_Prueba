package com.tfg.api.service;

import com.tfg.api.dto.UsuarioCreateDTO;
import com.tfg.api.dto.UsuarioDTO;

import java.util.List;

public interface UsuarioService {

    List<UsuarioDTO> findAll();

    UsuarioDTO findById(Integer id);

    UsuarioDTO save(UsuarioCreateDTO dto);

    UsuarioDTO update(Integer id, UsuarioDTO dto);

    void deleteById(Integer id);
}