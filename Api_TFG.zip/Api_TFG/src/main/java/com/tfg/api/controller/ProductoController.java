package com.tfg.api.controller;

import com.tfg.api.dto.ProductoDTO;
import com.tfg.api.service.ProductoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin(origins = "*")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @GetMapping
    public List<ProductoDTO> getAll() {
        return productoService.findAll();
    }

    @GetMapping("/{id}")
    public ProductoDTO getById(@PathVariable Integer id) {
        return productoService.findById(id);
    }

    @PostMapping
    public ProductoDTO create(@RequestBody ProductoDTO dto) {
        return productoService.save(dto);
    }

    @PutMapping("/{id}")
    public ProductoDTO update(@PathVariable Integer id, @RequestBody ProductoDTO dto) {
        return productoService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        productoService.deleteById(id);
    }
}