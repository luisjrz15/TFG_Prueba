package com.tfg.api.service;

import com.tfg.api.dto.FaqDTO;

import java.util.List;

public interface FaqService {

    List<FaqDTO> findAll();

    FaqDTO findById(Integer id);

    FaqDTO save(FaqDTO dto);

    FaqDTO update(Integer id, FaqDTO dto);

    void deleteById(Integer id);
}
