package com.tfg.api.entity;

public enum EstadoFormulario {
    Pendiente,
    En_Proceso,
    Completado
}
