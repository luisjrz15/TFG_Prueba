package com.tfg.api.repository;

import com.tfg.api.entity.Formulario;
import com.tfg.api.entity.EstadoFormulario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FormularioRepository extends JpaRepository<Formulario, Integer> {

    List<Formulario> findByUsuario_IdUsuario(Integer idUsuario);

    List<Formulario> findByEstado(EstadoFormulario estado);
}