package com.tfg.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTfgApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiTfgApplication.class, args);
	}

}
