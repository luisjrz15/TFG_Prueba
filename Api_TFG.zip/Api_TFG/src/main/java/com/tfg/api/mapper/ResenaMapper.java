package com.tfg.api.mapper;

import com.tfg.api.dto.ResenaDTO;
import com.tfg.api.entity.Resena;

public class ResenaMapper {

    public static ResenaDTO toDTO(Resena entity) {
        if (entity == null) return null;

        ResenaDTO dto = new ResenaDTO();
        dto.setIdResena(entity.getIdResena());
        dto.setPuntuacion(entity.getPuntuacion());
        dto.setComentario(entity.getComentario());
        dto.setFecha(entity.getFecha());

        if (entity.getProducto() != null) {
            dto.setIdProducto(entity.getProducto().getIdProducto());
        }

        if (entity.getUsuario() != null) {
            dto.setNombreUsuario(entity.getUsuario().getNombreUsuario());
        }

        return dto;
    }
}