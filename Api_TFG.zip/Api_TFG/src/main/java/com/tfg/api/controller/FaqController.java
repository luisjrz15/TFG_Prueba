package com.tfg.api.controller;

import com.tfg.api.entity.Faq;
import com.tfg.api.repository.FaqRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/faqs")
@CrossOrigin(origins = "*")
public class FaqController {

    private final FaqRepository faqRepository;

    public FaqController(FaqRepository faqRepository) {
        this.faqRepository = faqRepository;
    }

    @GetMapping
    public List<Faq> getAll() {
        return faqRepository.findAll();
    }
}