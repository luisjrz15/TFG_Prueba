package com.tfg.api.service;

import com.tfg.api.dto.CarritoDTO;

import java.util.List;

public interface CarritoService {

    List<CarritoDTO> findByUsuario(Integer idUsuario);

    CarritoDTO save(CarritoDTO dto);

    void deleteById(Integer id);
}
