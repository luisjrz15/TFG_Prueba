package com.tfg.api.mapper;

import com.tfg.api.dto.UsuarioDTO;
import com.tfg.api.entity.Usuario;

public class UsuarioMapper {

    public static UsuarioDTO toDTO(Usuario entity) {
        UsuarioDTO dto = new UsuarioDTO();
        dto.setIdUsuario(entity.getIdUsuario());
        dto.setNombreUsuario(entity.getNombreUsuario());
        dto.setEmail(entity.getEmail());
        dto.setFechaRegistro(entity.getFechaRegistro());
        return dto;
    }
}