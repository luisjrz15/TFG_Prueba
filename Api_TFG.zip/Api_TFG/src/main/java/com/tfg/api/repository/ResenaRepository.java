package com.tfg.api.repository;

import com.tfg.api.entity.Resena;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ResenaRepository extends JpaRepository<Resena, Integer> {

    List<Resena> findByProductoIdProducto(Integer idProducto);

    List<Resena> findByUsuarioIdUsuario(Integer idUsuario);
}