package com.tfg.api.controller;

import com.tfg.api.dto.CarritoDTO;
import com.tfg.api.service.CarritoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/carrito")
@CrossOrigin(origins = "*")
public class CarritoController {

    private final CarritoService carritoService;

    public CarritoController(CarritoService carritoService) {
        this.carritoService = carritoService;
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<CarritoDTO> getByUsuario(@PathVariable Integer idUsuario) {
        return carritoService.findByUsuario(idUsuario);
    }

    @PostMapping
    public CarritoDTO add(@RequestBody CarritoDTO dto) {
        return carritoService.save(dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        carritoService.deleteById(id);
    }
}
