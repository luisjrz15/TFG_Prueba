package com.tfg.api.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "faqs")
public class Faq {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_faq")
    private Integer idFaq;

    @Column(nullable = false, length = 255)
    private String pregunta;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String respuesta;

    public Faq() {}

    // getters y setters
    public Integer getIdFaq() { return idFaq; }
    public void setIdFaq(Integer idFaq) { this.idFaq = idFaq; }

    public String getPregunta() { return pregunta; }
    public void setPregunta(String pregunta) { this.pregunta = pregunta; }

    public String getRespuesta() { return respuesta; }
    public void setRespuesta(String respuesta) { this.respuesta = respuesta; }
}