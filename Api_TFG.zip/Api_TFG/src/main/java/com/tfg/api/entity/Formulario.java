package com.tfg.api.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "FORMULARIO")
public class Formulario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_formulario")
    private Integer idFormulario;

    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;

    @Enumerated(EnumType.STRING)
    private Servicio servicio;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String descripcion;

    private BigDecimal presupuesto;

    @Enumerated(EnumType.STRING)
    private EstadoFormulario estado;

    public Formulario() {}

    // getters y setters
    public Integer getIdFormulario() { return idFormulario; }
    public void setIdFormulario(Integer idFormulario) { this.idFormulario = idFormulario; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public Servicio getServicio() { return servicio; }
    public void setServicio(Servicio servicio) { this.servicio = servicio; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getPresupuesto() { return presupuesto; }
    public void setPresupuesto(BigDecimal presupuesto) { this.presupuesto = presupuesto; }

    public EstadoFormulario getEstado() { return estado; }
    public void setEstado(EstadoFormulario estado) { this.estado = estado; }
}