package com.tfg.api.controller;

import com.tfg.api.dto.FormularioDTO;
import com.tfg.api.service.FormularioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/formularios")
@CrossOrigin(origins = "*")
public class FormularioController {

    private final FormularioService formularioService;

    public FormularioController(FormularioService formularioService) {
        this.formularioService = formularioService;
    }

    @GetMapping
    public List<FormularioDTO> getAll() {
        return formularioService.findAll();
    }

    @GetMapping("/{id}")
    public FormularioDTO getById(@PathVariable Integer id) {
        return formularioService.findById(id);
    }

    @PostMapping
    public FormularioDTO create(@RequestBody FormularioDTO dto) {
        return formularioService.save(dto);
    }

    @PutMapping("/{id}")
    public FormularioDTO update(@PathVariable Integer id, @RequestBody FormularioDTO dto) {
        return formularioService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        formularioService.deleteById(id);
    }
}
