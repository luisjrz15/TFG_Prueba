package com.tfg.api.dto;

public class FaqDTO {

    private Integer idFaq;
    private String pregunta;
    private String respuesta;

    public FaqDTO() {}

    public Integer getIdFaq() { return idFaq; }
    public void setIdFaq(Integer idFaq) { this.idFaq = idFaq; }

    public String getPregunta() { return pregunta; }
    public void setPregunta(String pregunta) { this.pregunta = pregunta; }

    public String getRespuesta() { return respuesta; }
    public void setRespuesta(String respuesta) { this.respuesta = respuesta; }
}