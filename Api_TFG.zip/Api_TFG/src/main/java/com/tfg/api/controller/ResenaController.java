package com.tfg.api.controller;

import com.tfg.api.dto.ResenaCreateDTO;
import com.tfg.api.dto.ResenaDTO;
import com.tfg.api.service.ResenaService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/resenas")
@CrossOrigin(origins = "*")
public class ResenaController {

    private final ResenaService resenaService;

    public ResenaController(ResenaService resenaService) {
        this.resenaService = resenaService;
    }

    @GetMapping("/producto/{idProducto}")
    public List<ResenaDTO> getByProducto(@PathVariable Integer idProducto) {
        return resenaService.findByProducto(idProducto);
    }

    @PostMapping
    public ResponseEntity<ResenaDTO> create(@RequestBody ResenaCreateDTO dto) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(resenaService.save(dto));
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        resenaService.deleteById(id);
    }
}
