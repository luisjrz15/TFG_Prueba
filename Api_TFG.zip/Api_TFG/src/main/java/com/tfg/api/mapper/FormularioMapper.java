package com.tfg.api.mapper;

import com.tfg.api.dto.FormularioDTO;
import com.tfg.api.entity.Formulario;

public class FormularioMapper {

    public static FormularioDTO toDTO(Formulario entity) {
        if (entity == null) return null;

        FormularioDTO dto = new FormularioDTO();
        dto.setIdFormulario(entity.getIdFormulario());
        dto.setDescripcion(entity.getDescripcion());
        dto.setPresupuesto(entity.getPresupuesto());

        if (entity.getUsuario() != null) {
            dto.setIdUsuario(entity.getUsuario().getIdUsuario());
        }

        if (entity.getServicio() != null) {
            dto.setServicio(entity.getServicio().name());
        }

        if (entity.getEstado() != null) {
            dto.setEstado(entity.getEstado().name());
        }

        return dto;
    }
}
