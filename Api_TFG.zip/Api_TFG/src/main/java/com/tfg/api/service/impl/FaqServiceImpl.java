package com.tfg.api.service.impl;

import com.tfg.api.dto.FaqDTO;
import com.tfg.api.entity.Faq;
import com.tfg.api.mapper.FaqMapper;
import com.tfg.api.repository.FaqRepository;
import com.tfg.api.service.FaqService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FaqServiceImpl implements FaqService {

    private final FaqRepository faqRepository;

    public FaqServiceImpl(FaqRepository faqRepository) {
        this.faqRepository = faqRepository;
    }

    @Override
    public List<FaqDTO> findAll() {
        return faqRepository.findAll()
                .stream()
                .map(FaqMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public FaqDTO findById(Integer id) {
        Faq faq = faqRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("FAQ no encontrada"));

        return FaqMapper.toDTO(faq);
    }

    @Override
    public FaqDTO save(FaqDTO dto) {
        Faq faq = new Faq();
        faq.setPregunta(dto.getPregunta());
        faq.setRespuesta(dto.getRespuesta());

        return FaqMapper.toDTO(faqRepository.save(faq));
    }

    @Override
    public FaqDTO update(Integer id, FaqDTO dto) {
        Faq faq = faqRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("FAQ no encontrada"));

        faq.setPregunta(dto.getPregunta());
        faq.setRespuesta(dto.getRespuesta());

        return FaqMapper.toDTO(faqRepository.save(faq));
    }

    @Override
    public void deleteById(Integer id) {
        if (!faqRepository.existsById(id)) {
            throw new RuntimeException("FAQ no encontrada");
        }
        faqRepository.deleteById(id);
    }
}