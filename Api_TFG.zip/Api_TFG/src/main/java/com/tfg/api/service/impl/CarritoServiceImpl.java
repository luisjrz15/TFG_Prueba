package com.tfg.api.service.impl;

import com.tfg.api.dto.CarritoDTO;
import com.tfg.api.entity.Carrito;
import com.tfg.api.entity.Producto;
import com.tfg.api.entity.Usuario;
import com.tfg.api.mapper.CarritoMapper;
import com.tfg.api.repository.CarritoRepository;
import com.tfg.api.repository.ProductoRepository;
import com.tfg.api.repository.UsuarioRepository;
import com.tfg.api.service.CarritoService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CarritoServiceImpl implements CarritoService {

    private final CarritoRepository carritoRepository;
    private final UsuarioRepository usuarioRepository;
    private final ProductoRepository productoRepository;

    public CarritoServiceImpl(CarritoRepository carritoRepository,
                              UsuarioRepository usuarioRepository,
                              ProductoRepository productoRepository) {
        this.carritoRepository = carritoRepository;
        this.usuarioRepository = usuarioRepository;
        this.productoRepository = productoRepository;
    }

    @Override
    public List<CarritoDTO> findByUsuario(Integer idUsuario) {
        return carritoRepository.findByUsuarioIdUsuario(idUsuario)
                .stream()
                .map(CarritoMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CarritoDTO save(CarritoDTO dto) {
        Carrito carrito = new Carrito();

        Usuario usuario = usuarioRepository.findById(dto.getIdUsuario())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Producto producto = productoRepository.findById(dto.getProducto().getIdProducto())
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));

        carrito.setUsuario(usuario);
        carrito.setProducto(producto);
        carrito.setCantidad(dto.getCantidad());

        return CarritoMapper.toDTO(carritoRepository.save(carrito));
    }

    @Override
    public void deleteById(Integer id) {
        carritoRepository.deleteById(id);
    }
}
