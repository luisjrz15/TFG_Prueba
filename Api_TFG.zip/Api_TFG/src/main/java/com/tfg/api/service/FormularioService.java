package com.tfg.api.service;

import com.tfg.api.dto.FormularioDTO;
import java.util.List;

public interface FormularioService {

    List<FormularioDTO> findAll();

    FormularioDTO findById(Integer id);

    FormularioDTO save(FormularioDTO dto);

    FormularioDTO update(Integer id, FormularioDTO dto);

    void deleteById(Integer id);
}
