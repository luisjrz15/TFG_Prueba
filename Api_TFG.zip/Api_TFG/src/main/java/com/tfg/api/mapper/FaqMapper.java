package com.tfg.api.mapper;

import com.tfg.api.dto.FaqDTO;
import com.tfg.api.entity.Faq;

public class FaqMapper {

    public static FaqDTO toDTO(Faq entity) {
        if (entity == null) return null;

        FaqDTO dto = new FaqDTO();
        dto.setIdFaq(entity.getIdFaq());
        dto.setPregunta(entity.getPregunta());
        dto.setRespuesta(entity.getRespuesta());

        return dto;
    }
}